import React from 'react';
// import CollegeNavBar from './CollegeNavBar';

function CollegeCategory(props) {
    return (
        <div>

            <center>
                <br></br><br></br>
            <button className='btn btn-lg btn-primary'>Followed Colleges</button><br></br><br></br>
            <button className='btn btn-lg btn-primary'>Created Colleges</button>
            </center>
        </div>
    );
}

export default CollegeCategory;