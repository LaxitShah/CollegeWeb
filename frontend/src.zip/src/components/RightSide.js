import React from 'react';
import { Image } from 'react-bootstrap';

function RightSide(props) {
    return (
        <div>
             <Image src="https://res.cloudinary.com/dmkfgsff7/image/upload/v1647927035/CollegeWeb/866_qb5o1g.jpg" thumbnail style={{border:"none"}} /> 
        </div>
    );
}

export default RightSide;