import React from 'react';
import './App.css';
import MainComponent from './components/MainComponent';
import AcademicsList from './components/AcademicsList'

function App() {
  return (
    <div>
      <MainComponent />
      
       {/* <AcademicsList /> */}
    </div>
  );
}

export default App;




